This package runs CMake and sets variables for on the fly syntax checking
and auto-completion using clang.
