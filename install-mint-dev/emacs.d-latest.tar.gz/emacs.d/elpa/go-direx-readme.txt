go-direx.el provides tree style source code viewer for Go langue
using direx.

To use this package, add these lines to your .emacs.d/init.el:
    (require 'go-direx)

I recommend you use go-direx with popwin.el. You can control popup
buffer easily.
