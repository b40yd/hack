This helm source can be used to look up words in local (offline)
dictionaries.  It also provides short-cuts for various online
dictionaries, which is useful in situations where the local
dictionary doesn't have an entry for a word.

Dictionaries are available for a variety of language pairs.  See
the project page for an incomplete list:

    https://github.com/emacs-helm/helm-dictionary
