Auto Completion source for clang. Most of codes are taken from
company-clang.el and modified and enhanced for Auto Completion.
