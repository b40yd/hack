Jump through Go stacktraces easily.
