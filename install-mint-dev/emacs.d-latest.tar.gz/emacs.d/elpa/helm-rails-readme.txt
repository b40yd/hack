Helm Rails extension provides snappy navigation through rails
projects. It is possible to traverse through
resource and files related to the current file.
