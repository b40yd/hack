Tested on Emacs 24
